TIEKS TWEEWIELERS – MEDIA-PACKET (14 foto's, geoptimaliseerd naar WebP)

DOELBRANCH
Parsan123/tiekstweewielers → tieks/klantwijzigingen-oktober-2026

BELANGRIJK
- De websitecode is op de aparte branch voorbereid, maar deze 14 foto's ontbreken nog in de GitHub-branch.
- Upload deze bestanden op de aangegeven paden vóórdat je de branch samenvoegt of publiceert.
- Laat 'main' en de live Netlify-site voorlopig ongemoeid.

GITHUB UPLOAD (zonder terminal)
1. Open https://github.com/Parsan123/tiekstweewielers
2. Kies bij de branchkiezer: tieks/klantwijzigingen-oktober-2026
3. Open 'Add file' → 'Upload files'.
4. Sleep de map 'assets' uit dit uitgepakte ZIP-bestand naar het uploadvak (met onderliggende mappen products en showroom en team-2026.webp).
5. Controleer dat de bestanden het pad assets/... behouden.
6. Geef de commit als naam: Add original Tieks shop, team and Gazelle Curb images
7. Commit direct naar de genoemde ontwikkelbranch, NIET naar main.
8. Controleer daarna de foto's via GitHub en vóór publicatie op desktop en telefoon.

FOTOGEBRUIK
- Teamfoto: assets/team-2026.webp
- Gazelle Curb C1: assets/products/gazelle-curb-c1-*.webp
- Winkelfoto's: assets/showroom/*.webp
- Het pakket bevat ook twee optionele Koga/showroomfoto's, die wegens tijdelijke merkverwijdering niet prominent worden gebruikt.

Geen wijzigingen aan DNS, e-mailhosting of Netlify uitgevoerd.
